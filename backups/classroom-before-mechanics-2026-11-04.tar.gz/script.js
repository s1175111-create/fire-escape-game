const scenes = {
  family: {
    name: "家庭客厅", icon: "🏠", subtitle: "居家逃生演练", image: "assets/scenes/family-clean.png", ordered: true,
    mission: "先保护自己，再按顺序安全逃生", intro: "客厅出现轻微烟雾。第一要义是确保自身安全：先用湿毛巾保护口鼻，再按步骤行动！",
    summary: "家庭火灾小知识：先用湿毛巾保护自己，尽快离开家里，安全后拨打 119！",
    items: [
      { id: "towel", label: "湿毛巾", x: 27, y: 78, w: 15, h: 18, order: 1, shape: "inset(0 round 22%)", text: "太棒啦 🎉 先用湿毛巾捂住口鼻，挡住有毒浓烟，优先保护自己！" },
      { id: "extinguisher", label: "家用灭火器", x: 68, y: 50, w: 13, h: 25, order: 2, text: "答对咯 ✨ 确保自身安全后，初期小火可以使用灭火器灭火！" },
      { id: "door", label: "居家逃生门", x: 90, y: 38, w: 16, h: 34, order: 3, shape: "inset(0 round 12%)", text: "没错 👍 沿着路线，从家门安全逃离火场！" },
      { id: "phone", label: "报警电话", x: 44, y: 77, w: 15, h: 17, order: 4, text: "非常棒 📞 到达安全区域后拨打 119，通知消防员叔叔！" },
      { id: "curtain", label: "易燃窗帘", x: 11, y: 28, w: 12, h: 33, shape: "polygon(19% 0, 81% 0, 100% 88%, 76% 100%, 50% 92%, 22% 100%, 0 88%)", wrong: true, text: "小心哦 ⚠️ 窗帘很容易着火，火灾的时候远离它！" }
    ]
  },
  mall: {
    name: "商场公共区", icon: "🏬", subtitle: "公共场所逃生演练", image: "assets/scenes/mall-clean.png", ordered: true,
    mission: "先保护自己，再按顺序通过安全通道", intro: "商场上方出现烟雾。第一要义是确保自身安全：先保护口鼻，再按指引行动！",
    summary: "商场火灾小知识：跟着指示牌走安全通道，千万不要搭乘电梯逃生！",
    items: [
      { id: "hydrant", label: "消防栓", x: 31, y: 49, w: 14, h: 28, order: 2, shape: "inset(0 round 12%)", text: "很好！确保自身安全后，消防栓是商场重要的初期消防设备。" },
      { id: "sign", label: "疏散指示牌", x: 46, y: 21, w: 16, h: 13, order: 4, shape: "inset(0 round 18%)", text: "答对啦 ✨ 跟着疏散指示牌，找到逃生方向！" },
      { id: "door", label: "安全通道门", x: 87, y: 50, w: 19, h: 38, order: 5, shape: "inset(0 round 10%)", text: "太棒啦 👍 火灾逃生，走安全通道离开商场！" },
      { id: "towel", label: "湿毛巾取用点", x: 57, y: 60, w: 14, h: 26, order: 1, shape: "inset(0 round 15%)", text: "很好 ✅ 第一时间拿上湿毛巾，保护自己不吸入浓烟！" },
      { id: "broadcast", label: "应急广播", x: 70, y: 21, w: 12, h: 16, order: 3, text: "收到 📢 仔细听应急广播，听从工作人员指挥！" },
      { id: "elevator", label: "商场电梯", x: 12, y: 55, w: 20, h: 45, shape: "inset(0 round 10%)", wrong: true, text: "要记住哦 ⚠️ 火灾电梯很容易故障，逃生绝对不能坐电梯！" }
    ]
  },
  confined: {
    name: "密闭空间", icon: "🧰", subtitle: "应急避险演练", image: "assets/scenes/confined-clean.png", ordered: true,
    mission: "按正确顺序完成密闭空间逃生", intro: "密闭空间有烟雾，请按顺序做好准备并安全离开！",
    summary: "密闭空间小知识：先通风，再做好防护和照明，低姿沿安全方向离开。",
    items: [
      { id: "vent", label: "排风开关", x: 10, y: 35, w: 10, h: 17, order: 1, shape: "inset(0 round 15%)", text: "正确！先打开排风，帮助烟雾排出。" },
      { id: "mask", label: "防毒面罩", x: 43, y: 41, w: 15, h: 18, order: 2, text: "正确！戴好防护面罩，减少吸入有害烟雾。" },
      { id: "flashlight", label: "应急手电筒", x: 56, y: 42, w: 14, h: 13, order: 3, text: "正确！烟雾里视线不清，需要手电筒帮助辨认方向。" },
      { id: "cloth", label: "湿抹布", x: 40, y: 74, w: 15, h: 12, order: 4, shape: "inset(0 round 22%)", text: "正确！湿抹布可以辅助捂住口鼻。" },
      { id: "door", label: "密闭逃生门", x: 89, y: 44, w: 18, h: 38, order: 5, shape: "inset(0 round 10%)", text: "做得好！沿着安全出口撤离。" },
      { id: "boxes", label: "杂物纸箱", x: 10, y: 68, w: 18, h: 35, shape: "inset(0 round 10%)", wrong: true, text: "不要停下来翻找杂物，逃生时间很宝贵！" },
      { id: "bucket", label: "清水水桶", x: 29, y: 70, w: 13, h: 21, wrong: true, text: "不要在这里耽搁，请按安全步骤快速离开。" }
    ]
  },
  classroom: {
    name: "教室", icon: "🏫", subtitle: "校园逃生演练", image: "教室.jpg", ordered: true,
    mission: "按消防知识完成教室逃生", intro: "上课期间教室角落突发起火，请按正确顺序完成安全逃生！",
    summary: "教室火灾正确逃生口诀：捂口鼻、灭小火、辨方向、快撤离，不慌乱、不贪恋物品！",
    items: [
      { id: "towel", label: "湿毛巾", x: 67, y: 58, w: 13, h: 13, order: 1, shape: "inset(0 round 22%)", text: "正确！火灾浓烟有毒，需要捂住口鼻、弯腰逃生。" },
      { id: "clothes", label: "衣服", x: 70, y: 37, w: 12, h: 24, optional: true, shape: "polygon(25% 0, 75% 0, 100% 25%, 82% 100%, 18% 100%, 0 25%)", text: "衣服也能帮助遮住口鼻。优先使用湿毛巾，效果更好！" },
      { id: "hydrant", label: "消防栓", x: 81, y: 39, w: 12, h: 28, optional: true, shape: "inset(0 round 10%)", text: "消防栓是教室的重要消防设施，请在老师或工作人员指导下使用。" },
      { id: "extinguisher", label: "灭火器", x: 89, y: 79, w: 14, h: 29, order: 2, text: "正确！初期小火可以使用灭火器灭火，阻止火势蔓延。" },
      { id: "arrow", label: "安全出口方向", x: 75, y: 89, w: 20, h: 18, order: 3, shape: "inset(0 round 18%)", text: "认准安全出口方向，弯腰低姿快速撤离。" },
      { id: "door", label: "教室门", x: 94, y: 36, w: 15, h: 34, order: 4, shape: "inset(0 round 10%)", text: "🎉 逃生成功！你已掌握正确教室火灾逃生知识。" },
      { id: "book", label: "书本", x: 19, y: 67, w: 12, h: 14, wrong: true, text: "这不是逃生道具，不要浪费逃生时间！" },
      { id: "tissue", label: "纸巾盒", x: 42, y: 65, w: 12, h: 15, wrong: true, text: "这不是逃生道具，不要浪费逃生时间！" }
    ]
  }
};

const homeScreen = document.querySelector("#homeScreen");
const gameScreen = document.querySelector("#gameScreen");
const sceneImage = document.querySelector("#sceneImage");
const sceneName = document.querySelector("#sceneName");
const sceneIcon = document.querySelector("#sceneIcon");
const sceneSubtitle = document.querySelector("#sceneSubtitle");
const missionTitle = document.querySelector("#missionTitle");
const missionHint = document.querySelector("#missionHint");
const scoreValue = document.querySelector("#scoreValue");
const steps = document.querySelector("#steps");
const hotspots = document.querySelector("#hotspots");
const stage = document.querySelector("#stage");
const bubble = document.querySelector("#knowledgeBubble");
const bubbleText = document.querySelector("#knowledgeText");
const bubbleClose = document.querySelector("#knowledgeClose");
const modal = document.querySelector("#modal");
const modalKicker = document.querySelector("#modalKicker");
const modalTitle = document.querySelector("#modalTitle");
const modalText = document.querySelector("#modalText");
const modalButton = document.querySelector("#modalButton");

let game = null;
let bubbleTimer = null;

document.querySelectorAll(".scene-card").forEach((card) => card.addEventListener("click", () => startGame(card.dataset.scene)));
document.querySelector("#backHome").addEventListener("click", showHome);
document.querySelector("#restartButton").addEventListener("click", () => startGame(game.id));
document.querySelector("#hintButton").addEventListener("click", giveHint);
modalButton.addEventListener("click", () => {
  modal.classList.add("is-hidden");
  if (game?.finished) showHome();
});
bubbleClose.addEventListener("click", () => {
  window.clearTimeout(bubbleTimer);
  bubble.classList.add("is-hidden");
});

function startGame(id) {
  const scene = scenes[id];
  game = { id, score: 100, completed: new Set(), mistakes: new Set(), nextOrder: 1, scene };
  homeScreen.classList.add("is-hidden");
  gameScreen.classList.remove("is-hidden");
  sceneName.textContent = scene.name;
  sceneIcon.textContent = scene.icon;
  sceneSubtitle.textContent = scene.subtitle;
  missionTitle.textContent = scene.mission;
  missionHint.textContent = "第一要义：先确保自身安全，再按步骤依次点击黄色框内物品。";
  sceneImage.src = scene.image;
  sceneImage.alt = `${scene.name}火灾逃生互动场景`;
  renderGame();
  showBubble(scene.intro, "good");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function renderGame() {
  scoreValue.textContent = game.score;
  stage.classList.toggle("foggy", game.mistakes.size >= 2);
  const correctItems = game.scene.items
    .filter((item) => !item.wrong && !item.optional)
    .sort((a, b) => (a.order ?? Number.MAX_SAFE_INTEGER) - (b.order ?? Number.MAX_SAFE_INTEGER));
  steps.innerHTML = correctItems.map((item) => {
    const done = game.completed.has(item.id);
    const active = !done && (!game.scene.ordered || item.order === game.nextOrder);
    return `<li class="${done ? "done" : ""} ${active ? "active" : ""}">${done ? "✓ " : ""}${item.label}</li>`;
  }).join("");
  hotspots.innerHTML = "";
  game.scene.items.forEach((item) => {
    const button = document.createElement("button");
    const isDone = game.completed.has(item.id);
    button.type = "button";
    button.className = `hotspot ${isDone ? "completed" : ""}`;
    button.setAttribute("aria-label", item.label);
    button.dataset.id = item.id;
    button.style.left = `${item.x}%`;
    button.style.top = `${item.y}%`;
    button.style.setProperty("--hotspot-w", `${item.w || 9}%`);
    button.style.setProperty("--hotspot-h", `${item.h || 12}%`);
    if (item.shape) button.style.setProperty("--hotspot-shape", item.shape);
    button.disabled = isDone;
    button.addEventListener("click", () => chooseItem(item, button));
    hotspots.appendChild(button);
  });
}

function chooseItem(item, button) {
  if (item.wrong) {
    button.classList.add("wrong");
    if (!game.mistakes.has(item.id)) {
      game.mistakes.add(item.id);
      game.score = Math.max(0, game.score - 10);
    }
    showBubble(`❌ 第一要义是确保自身安全。${item.text}`, "bad");
    renderGame();
    return;
  }
  if (item.optional) {
    game.completed.add(item.id);
    showBubble(`✅ ${item.text}`, "good");
    renderGame();
    return;
  }
  if (game.scene.ordered && item.order !== game.nextOrder) {
    game.score = Math.max(0, game.score - 5);
    const current = game.scene.items.find((entry) => entry.order === game.nextOrder);
    showBubble(`⚠️ 先确保自身安全，完成「${current?.label || "当前步骤"}」，再进行「${item.label}」。`, "bad");
    renderGame();
    return;
  }
  game.completed.add(item.id);
  if (game.scene.ordered) game.nextOrder += 1;
  showBubble(`✅ ${item.text}`, "good");
  renderGame();
  const requiredDone = [...game.completed].filter((id) => {
    const entry = game.scene.items.find((candidate) => candidate.id === id);
    return entry && !entry.wrong && !entry.optional;
  }).length;
  if (requiredDone === game.scene.items.filter((entry) => !entry.wrong && !entry.optional).length) {
    window.setTimeout(showWin, 650);
  }
}

function showBubble(text, tone) {
  window.clearTimeout(bubbleTimer);
  bubbleText.textContent = text;
  bubble.className = `knowledge-bubble ${tone}`;
  bubbleTimer = window.setTimeout(() => bubble.classList.add("is-hidden"), 4200);
}

function giveHint() {
  const target = game.scene.ordered
    ? game.scene.items.find((item) => item.order === game.nextOrder)
    : game.scene.items.find((item) => !item.wrong && !game.completed.has(item.id));
  if (!target) return;
  const button = document.querySelector(`.hotspot[data-id="${target.id}"]`);
  if (button) {
    document.querySelectorAll(".hotspot.hinted").forEach((node) => node.classList.remove("hinted"));
    button.classList.add("hinted");
    showBubble(`💡 试着寻找「${target.label}」吧！`, "good");
    window.setTimeout(() => button.classList.remove("hinted"), 2800);
  }
}

function showWin() {
  game.finished = true;
  modalKicker.textContent = `最终得分 ${game.score} 分`;
  modalTitle.textContent = "🎉 恭喜通关！";
  modalText.textContent = game.scene.summary;
  modalButton.textContent = "继续探索";
  modal.classList.remove("is-hidden");
}

function showHome() {
  gameScreen.classList.add("is-hidden");
  homeScreen.classList.remove("is-hidden");
  modal.classList.add("is-hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
}
